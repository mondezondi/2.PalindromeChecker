/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.palindromchecker;

/**
 *
 * @author Lenovo-User
 */
public class App {
     public static boolean isPalindrome(int number){
         //function to check if the number is palindrome
         int originalNumber = number;
         int reversedNumber = 0;
         
         //reverse the number
         while (number > 0){
             int digit = number % 10;
             reversedNumber = reversedNumber * 10 + digit;
             number/=10;
         }
         //check if the reversed number is equal to the original number
         return originalNumber == reversedNumber;
     }
    public static void main(String[] args) {
        int number = 2020;//Number to check
        //Check if the number is palindrome and print the results
        if (isPalindrome(number)){
            System.out.println(number + " is a palindrome.");
        }else{
            System.out.println(number + " is not a palindrome. ");
        }
    }
}
